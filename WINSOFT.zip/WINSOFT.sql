----first question

--1--
select empno, [name], [lastname] from EMPLOYEESTABLE where 
[Address] like '%Hama%' 
and hiredate < (SELECT DATEADD(year, -10, GETDATE()))

--2--
select [name], [lastname] from EMPLOYEESTABLE a
inner join timetable b on a.empno = b.empno
where a.degree = 2 or (a.degree = 3 and b.StartWork <= cast('2003/05/25' as date))

--3--
select [name], [lastname] from EMPLOYEESTABLE a
inner join timetable b on a.empno = b.empno
where b.StartWork = '' or b.StartWork = null

--4--
update EMPLOYEESTABLE set Degree = degree + 1 where hiredate < (SELECT DATEADD(year, -4, GETDATE()))

--5--
select DEGREE, EmpNo from EMPLOYEESTABLE where degree > 21

--6--
select [name], [lastname], [Address], [Certificate] from EMPLOYEESTABLE where Contains([Address], '12%')


--======2nd question=====--

---1---
select a.EMPNO, [name], [lastname], CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2)) as DailyWorkHours from EMPLOYEESTABLE a
left join TIMETABLE b on a.EmpNo = b.EMPNO

---2---
select a.EmpNo, SUM(CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2))) as MonthlyWorkHours from EMPLOYEESTABLE a
left join TIMETABLE b on a.EmpNo = b.EMPNO group by a.EmpNo

--3--
select EMPNO, (SUM(CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2))) * 150) as MonthlySalary from TIMETABLE group by EMPNO



---======4th question======---
alter VIEW Make_View AS
select a.EMPNO, 
OT = SUM(case 
when CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2)) > 8 
	Then  8 * 150 + (CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2)) - 8) * 300
when CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2)) <= 8 
	Then (CAST(DATEDIFF(minute,StartWork,EndWork)/60.0 as decimal(18,2))) * 150
	else 0
end 
)
from TIMETABLE a group by a.EMPNO


---===5th question===----
CREATE SEQUENCE SEQ1  
    as int
    START WITH 15 
    INCREMENT BY 15
	MAXVALUE 200














	use Winsoft
	select * from  tblname

	insert into tblName
	values('2001', 'IT', 'Tony Stark')
		insert into tblName
	values('2002','Sales', 'Natalie Portman')
			insert into tblName
	values('2003','Sales', 'Angelina Jolie')
	insert into tblName
	values('2004','Accounting', 'Leonardo Dicaprio')
insert into TblDepartments
values('A1B2','IT')
insert into TblDepartments
values('C3D4','Sales')
insert into TblDepartments
values('E5F6','Accounting')


select * from tblname

alter database winsoft set single_user with rollback immediate

use WinsoftExam


	